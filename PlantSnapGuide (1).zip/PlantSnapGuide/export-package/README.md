# PlantID App - Mobile Conversion Package

This package contains everything needed to convert the PlantID app to a mobile app for Google Play Store.

## For No-Code Services (AppMySite, Appery.io, Thunkable)

### Option 1: Use the web version
1. Upload the files in the "web-version" folder to a web hosting service like Netlify, Vercel, or GitHub Pages
2. Use the URL of your hosted site with the mobile app conversion service
3. Configure the app according to the service's instructions

### Option 2: Use the source code
1. Provide the "source-code" folder to the service or developer
2. They will need to build the web app first, then convert it to a mobile app

## App Information
- Name: PlantID
- Description: See app-store-assets/app_description.txt
- Version: 1.0.0
- App Icon: See resources/icon.svg
- Splash Screen: See resources/splash.svg

## Technical Details
- Built with React, TypeScript, Vite, and Capacitor
- Uses Gemini AI for plant identification
- Includes Stripe integration for subscriptions
- Camera functionality for taking plant photos
