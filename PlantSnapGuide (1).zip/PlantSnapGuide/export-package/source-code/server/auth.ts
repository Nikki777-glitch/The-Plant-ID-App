import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as UserType, loginSchema, registerSchema } from "@shared/schema";
import jwt from "jsonwebtoken";

// Make the Express User interface use our User type
declare global {
  namespace Express {
    interface User extends UserType {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Secret key for JWT
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-for-development";

export function setupAuth(app: Express) {
  // Session setup for authentication
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "plant-id-session-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
      secure: process.env.NODE_ENV === "production",
    }
  };

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport local strategy for email/password auth
  passport.use(
    new LocalStrategy({ usernameField: 'email' }, 
    async (email, password, done) => {
      try {
        const user = await storage.getUserByEmail(email);
        if (!user) {
          return done(null, false, { message: "Invalid email or password" });
        }
        
        const passwordsMatch = await comparePasswords(password, user.password);
        if (passwordsMatch) {
          return done(null, user);
        } else {
          return done(null, false, { message: "Invalid email or password" });
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  // Configure serialization and deserialization
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Registration endpoint
  app.post("/api/register", async (req, res) => {
    try {
      // Validate the registration data
      const validationResult = registerSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation error", 
          details: validationResult.error.errors 
        });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(req.body.email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }
      
      // Check if username is already taken
      const existingUsername = await storage.getUserByUsername(req.body.username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already taken" });
      }
      
      // Create new user with hashed password
      const hashedPassword = await hashPassword(req.body.password);
      const userData = {
        email: req.body.email,
        username: req.body.username,
        password: hashedPassword
      };
      
      const user = await storage.createUser(userData);
      
      // Auto-login the user after registration
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ error: "Login failed after registration" });
        }
        res.status(201).json({ 
          id: user.id,
          email: user.email,
          username: user.username,
          subscriptionStatus: user.subscriptionStatus,
          trialEnd: user.trialEnd,
          isPremium: user.isPremium
        });
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Registration failed" });
    }
  });

  // Login endpoint
  app.post("/api/login", (req, res, next) => {
    // Validate login data
    const validationResult = loginSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: "Validation error", 
        details: validationResult.error.errors 
      });
    }
    
    passport.authenticate("local", (err: any, user: UserType | false, info: { message: string }) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ error: info?.message || "Authentication failed" });
      }
      
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({ 
          id: user.id,
          email: user.email,
          username: user.username,
          subscriptionStatus: user.subscriptionStatus,
          trialEnd: user.trialEnd,
          isPremium: user.isPremium
        });
      });
    })(req, res, next);
  });

  // Logout endpoint
  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Get current user endpoint
  app.get("/api/user", (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    const user = req.user;
    res.json({ 
      id: user.id,
      email: user.email,
      username: user.username,
      subscriptionStatus: user.subscriptionStatus,
      trialEnd: user.trialEnd,
      isPremium: user.isPremium
    });
  });
}

// Middleware to check if user is authenticated
export function isAuthenticated(req: any, res: any, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: "Authentication required" });
}

// Middleware to check if user has subscription
export function hasValidSubscription(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ error: "Authentication required" });
  }
  
  const user = req.user;
  const now = new Date();
  
  // Check if user is in free trial period
  if (user.subscriptionStatus === "free_trial" && user.trialEnd && new Date(user.trialEnd) > now) {
    return next();
  }
  
  // Check if user has active subscription
  if (user.subscriptionStatus === "active" && user.isPremium) {
    return next();
  }
  
  res.status(403).json({ error: "Subscription required", subscriptionNeeded: true });
}