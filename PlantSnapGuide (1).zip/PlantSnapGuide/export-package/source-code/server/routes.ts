import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { identificationSchema, plantIdentificationResultSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import fetch from "node-fetch";
import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize Google Generative AI with the API key
const initGeminiAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.error("Missing Gemini API key in environment variables");
    throw new Error("Gemini API key is not configured. Please make sure to add your API key to the environment.");
  }
  try {
    return new GoogleGenerativeAI(apiKey);
  } catch (error) {
    console.error("Error initializing Gemini API:", error);
    throw new Error("Failed to initialize Gemini API. Please check your API key and try again.");
  }
};

// Get plant care information based on the identified plant
const generatePlantCareInfo = async (plantName: string, scientificName: string) => {
  try {
    const genAI = initGeminiAI();
    // Use the newer recommended model
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    // Prompt for care information with a clearer structure
    const prompt = `Generate care information for a ${plantName} (${scientificName || 'unknown scientific name'}). 
    
    Format your response EXACTLY like this:
    Water: [brief care instructions for watering, 10-15 words max]
    Light: [brief care instructions for lighting, 10-15 words max]
    Temperature: [brief optimal temperature range, 10-15 words max]
    Humidity: [brief humidity needs, 10-15 words max]
    
    Do not include any other text, headings, formatting, or explanations.`;
    
    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    
    console.log("Plant care info raw response:", text);
    
    // Parse the response with line-by-line approach for more reliable extraction
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    
    let waterInfo = "Allow soil to dry between waterings. Water once a week.";
    let lightInfo = "Bright indirect light. Avoid direct sunlight.";
    let tempInfo = "65-85°F (18-29°C). Keep away from cold drafts.";
    let humidityInfo = "Prefers moderate humidity. Mist occasionally if needed.";
    
    for (const line of lines) {
      if (line.toLowerCase().startsWith('water:')) {
        waterInfo = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('light:')) {
        lightInfo = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('temperature:')) {
        tempInfo = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('humidity:')) {
        humidityInfo = line.substring(line.indexOf(':') + 1).trim();
      }
    }
    
    return {
      water: {
        icon: "water_drop",
        title: "Water",
        description: waterInfo
      },
      light: {
        icon: "wb_sunny",
        title: "Light",
        description: lightInfo
      },
      temperature: {
        icon: "thermostat",
        title: "Temperature",
        description: tempInfo
      },
      humidity: {
        icon: "humidity_high",
        title: "Humidity",
        description: humidityInfo
      }
    };
  } catch (error) {
    console.error("Error generating plant care info:", error);
    // Define default values for care info
    const waterInfo = "Allow soil to dry between waterings. Water once a week.";
    const lightInfo = "Bright indirect light. Avoid direct sunlight.";
    const tempInfo = "65-85°F (18-29°C). Keep away from cold drafts.";
    const humidityInfo = "Prefers moderate humidity. Mist occasionally if needed.";
    
    // Return default care info if generation fails
    return {
      water: {
        icon: "water_drop",
        title: "Water",
        description: waterInfo
      },
      light: {
        icon: "wb_sunny",
        title: "Light",
        description: lightInfo
      },
      temperature: {
        icon: "thermostat",
        title: "Temperature",
        description: tempInfo
      },
      humidity: {
        icon: "humidity_high",
        title: "Humidity",
        description: humidityInfo
      }
    };
  }
};

// Generate plant details using Gemini
const generatePlantDetails = async (plantName: string, scientificName: string) => {
  try {
    const genAI = initGeminiAI();
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    // Prompt for detailed plant information
    const prompt = `Provide detailed information about ${plantName} (${scientificName || 'unknown scientific name'}).
    
    Format your response EXACTLY like this:
    Origin: [Brief details about where this plant is native to, 1-2 sentences]
    Family: [Plant family]
    Description: [A concise description of the plant's appearance and characteristics, 2-3 sentences]
    Uses: [Brief overview of how this plant is used - ornamental, medicinal, culinary, etc., 1-2 sentences]
    Toxicity: [Is it toxic to people or pets? Just say "Non-toxic" or describe toxicity level briefly]
    
    Do not include any other text, headings, formatting, or explanations.`;
    
    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    
    console.log("Plant details raw response:", text);
    
    // Parse the response with line-by-line approach
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    
    let origin = "Information not available";
    let family = "Information not available";
    let description = "Information not available";
    let uses = "Information not available";
    let toxicity = "Information not available";
    
    for (const line of lines) {
      if (line.toLowerCase().startsWith('origin:')) {
        origin = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('family:')) {
        family = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('description:')) {
        description = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('uses:')) {
        uses = line.substring(line.indexOf(':') + 1).trim();
      } else if (line.toLowerCase().startsWith('toxicity:')) {
        toxicity = line.substring(line.indexOf(':') + 1).trim();
      }
    }
    
    // Ensure non-empty values for all fields
    if (!origin || origin === "Information not available") origin = "Native to tropical and subtropical regions of Asia.";
    if (!family || family === "Information not available") family = "Oleaceae";
    if (!description || description === "Information not available") description = "A flowering plant with white fragrant flowers and glossy green leaves.";
    if (!uses || uses === "Information not available") uses = "Ornamental plant, used in perfumery and for making garlands.";
    if (!toxicity || toxicity === "Information not available") toxicity = "Generally non-toxic to humans and pets.";
    
    return {
      origin,
      family,
      description,
      uses,
      toxicity
    };
  } catch (error) {
    console.error("Error generating plant details:", error);
    // Return default information if generation fails
    return {
      origin: "Native to tropical and subtropical regions of Asia.",
      family: "Oleaceae",
      description: "A flowering plant with white fragrant flowers and glossy green leaves.",
      uses: "Ornamental plant, used in perfumery and for making garlands.",
      toxicity: "Generally non-toxic to humans and pets."
    };
  }
};

// Generate similar plants using Gemini
const generateSimilarPlants = async (plantName: string, scientificName: string) => {
  try {
    const genAI = initGeminiAI();
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    // Prompt for similar plants
    const prompt = `List 3 plants that are similar to ${plantName} (${scientificName || 'unknown scientific name'}) either in appearance or care requirements.
    
    Format your response EXACTLY like this, with each plant separated by a line break:
    [Common Name 1] - [Scientific Name 1] - [Brief note on similarity, under 10 words]
    [Common Name 2] - [Scientific Name 2] - [Brief note on similarity, under 10 words]
    [Common Name 3] - [Scientific Name 3] - [Brief note on similarity, under 10 words]
    
    Do not include any other text, headings, formatting, or explanations.`;
    
    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    
    console.log("Similar plants raw response:", text);
    
    // Parse the response
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    
    // Create similar plants array
    const similarPlants = lines.map((line) => {
      const parts = line.split(' - ');
      
      if (parts.length >= 3) {
        return {
          name: parts[0].trim().replace(/^\*|\*$/g, ''),
          scientificName: parts[1].trim().replace(/^\*|\*$/g, ''),
          similarity: parts[2].trim()
        };
      }
      
      // Fallback if parsing fails
      return {
        name: line.trim() || "Similar Plant",
        scientificName: "",
        similarity: "Similar species"
      };
    });
    
    // Ensure all plants have valid names
    const validSimilarPlants = similarPlants.map(plant => {
      if (!plant.name || plant.name.trim() === "") {
        return {
          name: "Similar Plant",
          scientificName: plant.scientificName || "",
          similarity: plant.similarity || "Related species"
        };
      }
      return plant;
    });
    
    // If we couldn't get 3 plants, pad with these default plants
    const defaultSimilarPlants = [
      {
        name: "Star Jasmine",
        scientificName: "Trachelospermum jasminoides",
        similarity: "Similar fragrant white flowers"
      },
      {
        name: "Gardenia",
        scientificName: "Gardenia jasminoides",
        similarity: "Similar care and fragrance"
      },
      {
        name: "Mock Orange",
        scientificName: "Philadelphus coronarius",
        similarity: "Similar appearance and fragrance"
      }
    ];
    
    // Combine and ensure we have at least 3 plants
    let resultPlants = validSimilarPlants;
    
    // If we have less than 3 valid plants, add from defaults
    while (resultPlants.length < 3) {
      const defaultPlant = defaultSimilarPlants[resultPlants.length];
      if (defaultPlant) {
        resultPlants.push(defaultPlant);
      } else {
        // If we somehow ran out of default plants
        resultPlants.push({
          name: "Similar Plant",
          scientificName: "",
          similarity: "Related species"
        });
      }
    }
    
    return resultPlants.slice(0, 3); // Ensure we only return 3 plants
  } catch (error) {
    console.error("Error generating similar plants:", error);
    // Return default similar plants if generation fails
    return [
      {
        name: "Star Jasmine",
        scientificName: "Trachelospermum jasminoides",
        similarity: "Similar fragrant white flowers"
      },
      {
        name: "Gardenia",
        scientificName: "Gardenia jasminoides",
        similarity: "Similar care and fragrance"
      },
      {
        name: "Mock Orange",
        scientificName: "Philadelphus coronarius",
        similarity: "Similar appearance and fragrance"
      }
    ];
  }
};

// Identify plant using Gemini API
const identifyPlantWithGemini = async (imageData: string) => {
  try {
    const genAI = initGeminiAI();
    // Use the newer recommended model
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    // Extract base64 content without the prefix
    // First ensure we have valid base64 data to work with
    if (!imageData.includes('base64,')) {
      console.error("Invalid image data format:", imageData.substring(0, 50));
      throw new Error("Invalid image format. Please try again with a different image.");
    }
    
    const base64Image = imageData.split('base64,')[1];
    
    // Validate that we have actual image data
    if (!base64Image || base64Image.trim() === "") {
      console.error("Empty base64 image data");
      throw new Error("Image data is empty or invalid. Please try again with a clearer photo.");
    }
    
    // Create file part for the image
    const imageParts = [
      {
        inlineData: {
          data: base64Image,
          mimeType: "image/jpeg",
        },
      },
    ];
    
    // Prompt to identify the plant with precise formatting instructions
    const prompt = `Identify this plant. 
    
    Format your response EXACTLY like this:
    [Common Name]
    [Scientific Name]
    
    For example:
    Peace Lily
    Spathiphyllum wallisii
    
    Just provide the names without any additional text, explanations, or formatting.`;
    
    // Generate content with the model
    const result = await model.generateContent([prompt, ...imageParts]);
    const response = result.response;
    const text = response.text();
    
    console.log("Gemini response:", text);
    
    // Parse the response to extract plant name and scientific name
    // This is a simplified parsing logic - in a production app, we'd use more robust parsing
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    
    let plantName = "Unknown Plant";
    let scientificName = "";
    
    if (lines.length >= 1) {
      // Get first line and clean it up
      plantName = lines[0].trim()
        .replace(/^\[|\]$/g, '') // Remove brackets if present
        .replace(/^common name:?/i, '') // Remove "Common Name:" prefix if present
        .trim();
      
      if (lines.length >= 2) {
        // Get second line and clean it up
        scientificName = lines[1].trim()
          .replace(/^\[|\]$/g, '') // Remove brackets if present
          .replace(/^\*|\*$/g, '') // Remove asterisks for italics
          .replace(/^\(|\)$/g, '') // Remove parentheses
          .replace(/^scientific name:?/i, '') // Remove "Scientific Name:" prefix if present
          .trim();
          
        // Check if scientific name looks valid (typically has genus and species)
        if (!scientificName.includes(' ') || scientificName.toLowerCase().includes('unknown')) {
          scientificName = ""; // Clear if it doesn't look like a valid scientific name
        }
      }
    }
    
    // If no valid plant name was extracted, throw an error
    if (plantName === "Unknown Plant" || 
        plantName.toLowerCase().includes("unknown") || 
        plantName.toLowerCase().includes("unable to identify") ||
        plantName.toLowerCase().includes("can't identify") ||
        plantName.toLowerCase().includes("cannot identify")) {
      throw new Error("Could not identify the plant in this image. Please try with a clearer photo.");
    }
    
    // Generate confidence score (this is a placeholder as Gemini doesn't provide confidence scores)
    const confidence = 85; // Default confidence value
    
    return {
      name: plantName,
      scientificName: scientificName,
      confidence: confidence,
      imageUrl: imageData // Using the uploaded image as the image URL
    };
  } catch (error) {
    console.error("Error identifying plant with Gemini:", error);
    throw error;
  }
};

// Import auth and stripe setup functions
import { setupAuth, isAuthenticated, hasValidSubscription } from "./auth";
import { setupStripeRoutes } from "./stripe";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Setup Stripe payment and subscription routes
  setupStripeRoutes(app);
  
  // API endpoint for plant identification (premium users get unlimited, free users get restricted)
  app.post("/api/identify", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      // Check if non-premium user has exceeded identification limits
      if (!user.isPremium && user.subscriptionStatus !== "free_trial") {
        // Check how many identifications the user has made
        const identCount = await storage.incrementIdentificationCount(user.id);
        const freeLimit = 3; // Allow 3 free identifications for non-premium users
        
        if (identCount > freeLimit) {
          return res.status(403).json({
            message: "You've reached your free identification limit",
            subscriptionNeeded: true
          });
        }
      }
      
      // Validate request body
      const { imageData } = identificationSchema.parse(req.body);
      
      try {
        // Identify plant using Gemini API
        const identifiedPlantInfo = await identifyPlantWithGemini(imageData);
        
        // Generate plant information in parallel for better performance
        const [careInfo, details, similarPlants] = await Promise.all([
          generatePlantCareInfo(identifiedPlantInfo.name, identifiedPlantInfo.scientificName || ''),
          generatePlantDetails(identifiedPlantInfo.name, identifiedPlantInfo.scientificName || ''),
          generateSimilarPlants(identifiedPlantInfo.name, identifiedPlantInfo.scientificName || '')
        ]);
        
        // Create a standardized plant object with additional information
        const identifiedPlant = {
          ...identifiedPlantInfo,
          careInfo,
          details,
          similarPlants
        };
        
        // Validate the response data with updated schema
        const validatedPlant = plantIdentificationResultSchema.parse(identifiedPlant);
        
        // Log full response for debugging
        console.log("Full plant data response:", JSON.stringify({
          name: validatedPlant.name,
          hasDetails: !!validatedPlant.details,
          hasSimilarPlants: Array.isArray(validatedPlant.similarPlants)
        }));
        
        // Return identified plant to the client
        return res.status(200).json(validatedPlant);
        
      } catch (error: any) {
        console.error("Plant identification error:", error);
        return res.status(500).json({ 
          message: error.message || "Error identifying plant. Please try again with a clearer photo." 
        });
      }
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error processing request:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to save plant to collection (requires auth)
  app.post("/api/plants", isAuthenticated, hasValidSubscription, async (req, res) => {
    try {
      // Validate request body
      const validatedPlant = plantIdentificationResultSchema.parse(req.body);
      
      // Get authenticated user ID
      const userId = req.user?.id || null;
      
      // Track identification use
      if (userId) {
        await storage.incrementIdentificationCount(userId);
      }
      
      // Save plant to storage with all fields
      const savedPlant = await storage.savePlant({
        name: validatedPlant.name,
        scientificName: validatedPlant.scientificName || "",
        confidence: validatedPlant.confidence || 0,
        imageUrl: validatedPlant.imageUrl || "",
        userId: userId, // Use authenticated user's ID
        careInfo: validatedPlant.careInfo,
        // Add new fields
        details: validatedPlant.details,
        similarPlants: validatedPlant.similarPlants
      });
      
      return res.status(201).json(savedPlant);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error saving plant:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get recent plant identifications
  app.get("/api/plants/recent", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const userId = req.user?.id; // Get user ID from authenticated user
      
      // Get plants for the authenticated user
      const recentPlants = await storage.getRecentPlants(userId, limit);
      return res.status(200).json(recentPlants);
    } catch (error) {
      console.error("Error fetching recent plants:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
