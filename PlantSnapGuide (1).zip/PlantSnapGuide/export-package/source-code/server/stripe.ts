import Stripe from "stripe";
import { Express } from "express";
import { storage } from "./storage";
import { isAuthenticated } from "./auth";
import { User } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

// Initialize Stripe with latest API version
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Monthly subscription price in cents ($0.99)
const SUBSCRIPTION_PRICE_CENTS = 99;

export function setupStripeRoutes(app: Express) {
  // Create a payment intent for one-time payment
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: SUBSCRIPTION_PRICE_CENTS,
        currency: "usd",
        metadata: {
          userId: req.user!.id.toString()
        }
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Create a new Stripe customer and subscription
  app.post("/api/subscribe", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      // Create or retrieve Stripe customer
      let customerId = user.stripeCustomerId;
      
      if (!customerId) {
        // Create a new customer
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.username,
          metadata: {
            userId: user.id.toString()
          }
        });
        
        customerId = customer.id;
        await storage.updateStripeCustomerId(user.id, customerId);
      }
      
      // First, create a product for our subscription if it doesn't exist
      let product;
      try {
        // Try to retrieve existing product
        const products = await stripe.products.list({
          limit: 1,
          active: true
        });
        
        if (products.data.length > 0) {
          product = products.data[0];
        } else {
          // Create a new product
          product = await stripe.products.create({
            name: 'PlantID Premium Monthly',
            description: 'Unlimited plant identifications',
          });
        }
      } catch (err) {
        console.error('Error creating/getting product:', err);
        throw err;
      }
      
      // Create a price for the product
      let price;
      try {
        // Try to retrieve existing price
        const prices = await stripe.prices.list({
          product: product.id,
          active: true,
          limit: 1
        });
        
        if (prices.data.length > 0) {
          price = prices.data[0];
        } else {
          // Create a new price
          price = await stripe.prices.create({
            product: product.id,
            unit_amount: SUBSCRIPTION_PRICE_CENTS,
            currency: 'usd',
            recurring: { interval: 'month' },
          });
        }
      } catch (err) {
        console.error('Error creating/getting price:', err);
        throw err;
      }
      
      // Create a subscription with the price
      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: price.id }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });
      
      // Save the subscription ID to the user
      await storage.updateUser(user.id, {
        stripeSubscriptionId: subscription.id
      });
      
      // Access the payment intent through the expanded subscription data
      const latestInvoice = subscription.latest_invoice as any;
      const paymentIntent = latestInvoice.payment_intent as any;
      
      res.json({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Cancel a subscription
  app.post("/api/cancel-subscription", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      if (!user.stripeSubscriptionId) {
        return res.status(400).json({ error: "No active subscription found" });
      }
      
      // Get subscription details
      const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
      
      // Cancel subscription at period end
      await stripe.subscriptions.update(subscription.id, {
        cancel_at_period_end: true
      });
      
      // Update user's subscription status
      await storage.updateSubscriptionStatus(user.id, "canceled");
      
      res.json({ success: true, message: "Subscription scheduled for cancellation" });
    } catch (error: any) {
      console.error("Error canceling subscription:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Reactivate a canceled subscription
  app.post("/api/reactivate-subscription", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      if (!user.stripeSubscriptionId) {
        return res.status(400).json({ error: "No subscription found" });
      }
      
      // Get subscription details
      const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
      
      // Only reactivate if it's set to cancel at period end
      if (subscription.cancel_at_period_end) {
        await stripe.subscriptions.update(subscription.id, {
          cancel_at_period_end: false
        });
        
        // Update user's subscription status
        await storage.updateSubscriptionStatus(user.id, "active");
        
        res.json({ success: true, message: "Subscription reactivated" });
      } else {
        res.status(400).json({ error: "Subscription is not scheduled for cancellation" });
      }
    } catch (error: any) {
      console.error("Error reactivating subscription:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Get subscription info
  app.get("/api/subscription", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      // For users in trial period
      if (user.subscriptionStatus === "free_trial" && user.trialEnd) {
        const now = new Date();
        const trialEnd = new Date(user.trialEnd);
        
        if (trialEnd > now) {
          const daysLeft = Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          return res.json({
            status: "free_trial",
            trialEnd: user.trialEnd,
            daysLeft,
            isPremium: false
          });
        }
      }
      
      // For users with subscriptions
      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        
        // Handle subscription period end date for UI display
        const currentPeriodEnd = (subscription as any).current_period_end;
        const periodEndDate = currentPeriodEnd ? new Date(currentPeriodEnd * 1000) : null;
        
        return res.json({
          status: subscription.status,
          currentPeriodEnd: periodEndDate,
          cancelAtPeriodEnd: subscription.cancel_at_period_end,
          isPremium: user.isPremium
        });
      }
      
      // For users with expired trials and no subscription
      res.json({
        status: "inactive",
        isPremium: false
      });
    } catch (error: any) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Create a checkout session for payment
  app.post("/api/create-checkout-session", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      // First, create a product for our subscription if it doesn't exist
      let product;
      try {
        // Try to retrieve existing product
        const products = await stripe.products.list({
          limit: 1,
          active: true
        });
        
        if (products.data.length > 0) {
          product = products.data[0];
        } else {
          // Create a new product
          product = await stripe.products.create({
            name: 'PlantID Premium Monthly',
            description: 'Unlimited plant identifications',
          });
        }
      } catch (err) {
        console.error('Error creating/getting product:', err);
        throw err;
      }
      
      // Create a price for the product
      let price;
      try {
        // Try to retrieve existing price
        const prices = await stripe.prices.list({
          product: product.id,
          active: true,
          limit: 1
        });
        
        if (prices.data.length > 0) {
          price = prices.data[0];
        } else {
          // Create a new price
          price = await stripe.prices.create({
            product: product.id,
            unit_amount: SUBSCRIPTION_PRICE_CENTS,
            currency: 'usd',
            recurring: { interval: 'month' },
          });
        }
      } catch (err) {
        console.error('Error creating/getting price:', err);
        throw err;
      }
      
      // Create a checkout session with the price
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price: price.id,
            quantity: 1,
          },
        ],
        mode: "subscription",
        success_url: `${req.headers.origin}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.headers.origin}/subscription/cancel`,
        customer_email: user.email,
        client_reference_id: user.id.toString(),
      });
      
      res.json({ url: session.url });
    } catch (error: any) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Handle Stripe webhook events
  app.post('/api/webhook', async (req, res) => {
    const payload = req.body;
    const sig = req.headers['stripe-signature'] as string;
    
    let event;
    
    // Verify webhook signature (in production, get webhook secret from env)
    try {
      // In production, uncomment this line and set the webhook secret:
      // event = stripe.webhooks.constructEvent(payload, sig, process.env.STRIPE_WEBHOOK_SECRET);
      
      // For development, we'll process the event without verification:
      event = payload;
    } catch (err: any) {
      console.error(`Webhook Error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    
    // Handle the event
    switch (event.type) {
      case 'invoice.paid':
        const invoice = event.data.object;
        await handleInvoicePaid(invoice);
        break;
      case 'customer.subscription.updated':
        const subscription = event.data.object;
        await handleSubscriptionUpdated(subscription);
        break;
      case 'customer.subscription.deleted':
        const deletedSubscription = event.data.object;
        await handleSubscriptionDeleted(deletedSubscription);
        break;
      // Add more cases for events you want to handle
    }
    
    res.json({ received: true });
  });
  
  // Helper function for handling invoice.paid event
  async function handleInvoicePaid(invoice: any) {
    if (invoice.subscription) {
      const subscription = await stripe.subscriptions.retrieve(invoice.subscription);
      const customerId = typeof subscription.customer === 'object' 
        ? subscription.customer.id 
        : subscription.customer;
      
      // Find user by customer ID
      const users = storage.getNonPrivateUsers();
      const user = users.find(u => u.stripeCustomerId === customerId) as User;
      
      if (user && user.id) {
        // Update user's subscription status
        const currentPeriodEnd = (subscription as any).current_period_end;
        const subscriptionEndDate = new Date(currentPeriodEnd * 1000);
        await storage.updateSubscriptionStatus(user.id, "active", subscriptionEndDate);
        await storage.updateUser(user.id, { isPremium: true });
      }
    }
  }
  
  // Helper function for handling subscription.updated event
  async function handleSubscriptionUpdated(subscription: any) {
    const customerId = typeof subscription.customer === 'object' 
      ? subscription.customer.id 
      : subscription.customer;
    
    // Find user by customer ID
    const users = storage.getNonPrivateUsers();
    const user = users.find(u => u.stripeCustomerId === customerId) as User;
    
    if (user && user.id) {
      const status = subscription.status;
      const isPremium = status === "active";
      
      const currentPeriodEnd = (subscription as any).current_period_end;
      const endDate = currentPeriodEnd ? new Date(currentPeriodEnd * 1000) : undefined;
      
      await storage.updateSubscriptionStatus(user.id, status, endDate);
      await storage.updateUser(user.id, { isPremium });
    }
  }
  
  // Helper function for handling subscription.deleted event
  async function handleSubscriptionDeleted(subscription: any) {
    const customerId = typeof subscription.customer === 'object' 
      ? subscription.customer.id 
      : subscription.customer;
    
    // Find user by customer ID
    const users = storage.getNonPrivateUsers();
    const user = users.find(u => u.stripeCustomerId === customerId) as User;
    
    if (user && user.id) {
      await storage.updateSubscriptionStatus(user.id, "canceled");
      await storage.updateUser(user.id, { isPremium: false });
    }
  }
}