import { plants, users, type User, type InsertUser, type Plant, type InsertPlant, type PlantIdentificationResult, type PlantDetails, type SimilarPlant } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  updateStripeCustomerId(userId: number, customerId: string): Promise<User | undefined>;
  updateSubscriptionStatus(userId: number, status: string, endDate?: Date): Promise<User | undefined>;
  updateTrialEnd(userId: number, trialEnd: Date): Promise<User | undefined>;
  incrementIdentificationCount(userId: number): Promise<number>;
  getPlant(id: number): Promise<Plant | undefined>;
  getRecentPlants(userId?: number, limit?: number): Promise<Plant[]>;
  savePlant(plant: InsertPlant): Promise<Plant>;
  getNonPrivateUsers(): User[];
  sessionStore: session.Store; // Type for express-session
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private plants: Map<number, Plant>;
  private userIdCounter: number;
  private plantIdCounter: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.plants = new Map();
    this.userIdCounter = 1;
    this.plantIdCounter = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    
    // Set up subscription trial period (7 days from now)
    const now = new Date();
    const trialEnd = new Date(now);
    trialEnd.setDate(trialEnd.getDate() + 7);
    
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      subscriptionStatus: "free_trial",
      subscriptionEnd: null,
      trialEnd: trialEnd,
      identificationCount: 0,
      isPremium: false
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateStripeCustomerId(userId: number, customerId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, stripeCustomerId: customerId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateSubscriptionStatus(
    userId: number, 
    status: string, 
    endDate?: Date
  ): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      subscriptionStatus: status,
      subscriptionEnd: endDate || user.subscriptionEnd,
      isPremium: status === "active"
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateTrialEnd(userId: number, trialEnd: Date): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, trialEnd };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async incrementIdentificationCount(userId: number): Promise<number> {
    const user = this.users.get(userId);
    if (!user) return 0;
    
    const newCount = (user.identificationCount || 0) + 1;
    const updatedUser = { ...user, identificationCount: newCount };
    this.users.set(userId, updatedUser);
    return newCount;
  }

  async getPlant(id: number): Promise<Plant | undefined> {
    return this.plants.get(id);
  }

  async getRecentPlants(userId?: number, limit = 5): Promise<Plant[]> {
    const plants = Array.from(this.plants.values())
      .filter(plant => userId ? plant.userId === userId : true)
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      })
      .slice(0, limit);
    
    return plants;
  }

  async savePlant(insertPlant: InsertPlant): Promise<Plant> {
    const id = this.plantIdCounter++;
    const now = new Date();
    
    // Extract any additional properties that might be in the input but not in InsertPlant type
    const details = (insertPlant as any).details as PlantDetails | null;
    const similarPlants = (insertPlant as any).similarPlants as SimilarPlant[] | null;
    
    // Create plant with all fields properly typed
    const plant: Plant = { 
      id,
      name: insertPlant.name,
      scientificName: insertPlant.scientificName || null,
      confidence: insertPlant.confidence || null,
      imageUrl: insertPlant.imageUrl || null,
      userId: insertPlant.userId || null,
      createdAt: now,
      careInfo: insertPlant.careInfo || null,
      details: details || null,
      similarPlants: similarPlants || null
    };
    
    this.plants.set(id, plant);
    return plant;
  }
  
  // Get all users with non-private data
  getNonPrivateUsers(): User[] {
    return Array.from(this.users.values()).map(user => {
      // Creating a new object excluding the password
      const { password, ...publicUserData } = user;
      return publicUserData as User;
    });
  }
}

export const storage = new MemStorage();