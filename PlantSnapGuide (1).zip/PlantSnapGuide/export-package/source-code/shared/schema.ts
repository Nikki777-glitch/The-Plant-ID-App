import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  
  // Subscription related fields
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  subscriptionStatus: text("subscription_status").default("free_trial"),
  subscriptionEnd: timestamp("subscription_end"),
  trialEnd: timestamp("trial_end"),
  identificationCount: integer("identification_count").default(0),
  isPremium: boolean("is_premium").default(false)
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
  password: true,
});

export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6, "Password must be at least 6 characters")
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

export type LoginUser = z.infer<typeof loginSchema>;
export type RegisterUser = z.infer<typeof registerSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const plants = pgTable("plants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  scientificName: text("scientific_name"),
  confidence: integer("confidence"),
  imageUrl: text("image_url"),
  userId: integer("user_id"),
  createdAt: timestamp("created_at").defaultNow(),
  careInfo: jsonb("care_info").$type<PlantCareInfo>(),
  details: jsonb("details").$type<PlantDetails>(),
  similarPlants: jsonb("similar_plants").$type<SimilarPlant[]>(),
});

export type PlantCareInfo = {
  water: {
    icon: string;
    title: string;
    description: string;
  };
  light: {
    icon: string;
    title: string;
    description: string;
  };
  temperature: {
    icon: string;
    title: string;
    description: string;
  };
  humidity: {
    icon: string;
    title: string;
    description: string;
  };
};

export const insertPlantSchema = createInsertSchema(plants).omit({
  id: true,
  createdAt: true
});

export type InsertPlant = z.infer<typeof insertPlantSchema>;
export type Plant = typeof plants.$inferSelect;

export const identificationSchema = z.object({
  imageData: z.string().min(1, "Image is required"),
});

export type IdentificationRequest = z.infer<typeof identificationSchema>;

// Plant details schema
export const plantDetailsSchema = z.object({
  origin: z.string(),
  family: z.string(),
  description: z.string(),
  uses: z.string(),
  toxicity: z.string()
});

export type PlantDetails = z.infer<typeof plantDetailsSchema>;

// Similar plant schema
export const similarPlantSchema = z.object({
  name: z.string(),
  scientificName: z.string().optional().nullable(),
  similarity: z.string()
});

export type SimilarPlant = z.infer<typeof similarPlantSchema>;

export const plantIdentificationResultSchema = z.object({
  id: z.number().optional(),
  name: z.string(),
  scientificName: z.string().optional(),
  confidence: z.number().optional(),
  imageUrl: z.string().optional(),
  createdAt: z.string().optional(),
  careInfo: z.object({
    water: z.object({
      icon: z.string(),
      title: z.string(),
      description: z.string()
    }),
    light: z.object({
      icon: z.string(),
      title: z.string(),
      description: z.string()
    }),
    temperature: z.object({
      icon: z.string(),
      title: z.string(),
      description: z.string()
    }),
    humidity: z.object({
      icon: z.string(),
      title: z.string(),
      description: z.string()
    })
  }).optional(),
  // New fields for details and similar plants
  details: plantDetailsSchema.optional(),
  similarPlants: z.array(similarPlantSchema).optional()
});

export type PlantIdentificationResult = z.infer<typeof plantIdentificationResultSchema>;
