#!/bin/bash

# Build the web app for production
echo "Building web app..."
npm run build

# Initialize Capacitor if not already done
if [ ! -d "android" ] && [ ! -d "ios" ]; then
  echo "Initializing Capacitor..."
  npx cap init PlantID com.plantid.app --web-dir=dist
fi

# Add platforms if not already added
if [ ! -d "android" ]; then
  echo "Adding Android platform..."
  npx cap add android
fi

if [ ! -d "ios" ]; then
  echo "Adding iOS platform..."
  npx cap add ios
fi

# Copy web assets to mobile projects
echo "Copying web assets to mobile projects..."
npx cap copy

# Sync plugins
echo "Syncing plugins..."
npx cap sync

echo "Mobile build completed. The Android and iOS projects are now ready."
echo ""
echo "Next steps:"
echo "1. Open Android Studio: npx cap open android"
echo "2. Open Xcode (Mac only): npx cap open ios"
echo ""
echo "For Android: Build the APK in Android Studio (Build > Build Bundle(s) / APK(s) > Build APK(s))"
echo "For iOS: Build the app in Xcode (requires macOS and Apple Developer account)"