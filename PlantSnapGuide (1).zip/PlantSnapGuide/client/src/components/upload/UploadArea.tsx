import React, { useRef, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { fileToBase64 } from '@/lib/plantApi';
import { isCapacitorEnvironment, selectImageWithCapacitor } from '@/lib/capacitorCamera';

interface UploadAreaProps {
  onImageUpload: (imageData: string) => void;
  onCameraClick: () => void;
  onSampleClick?: () => void;
}

export function UploadArea({ onImageUpload, onCameraClick, onSampleClick }: UploadAreaProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Debug information
  useEffect(() => {
    console.log("UploadArea component mounted");
  }, []);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log("File input changed", event.target.files);
    if (event.target.files && event.target.files[0]) {
      try {
        const file = event.target.files[0];
        console.log("Processing file:", file.name, file.type, file.size);
        const imageData = await fileToBase64(file);
        console.log("Image converted to base64");
        onImageUpload(imageData);
      } catch (error) {
        console.error('Error processing image:', error);
      }
    }
  };

  const triggerFileInput = async () => {
    console.log("Upload button clicked");
    
    // If we're in a Capacitor environment, use the native file picker
    if (isCapacitorEnvironment()) {
      console.log("Using Capacitor file picker");
      try {
        const imageData = await selectImageWithCapacitor();
        if (imageData) {
          console.log("Image selected with Capacitor");
          onImageUpload(imageData);
        }
      } catch (error) {
        console.error("Error selecting image with Capacitor:", error);
      }
      return;
    }
    
    // Web browser file input implementation
    if (fileInputRef.current) {
      console.log("Triggering file input click");
      fileInputRef.current.click();
    } else {
      console.error("File input reference is null");
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    console.log("File dropped", e.dataTransfer.files);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      try {
        const file = e.dataTransfer.files[0];
        console.log("Processing dropped file:", file.name, file.type, file.size);
        const imageData = await fileToBase64(file);
        console.log("Dropped image converted to base64");
        onImageUpload(imageData);
      } catch (error) {
        console.error('Error processing dropped image:', error);
      }
    }
  };

  // Direct file input element with visible button
  return (
    <div className="w-full max-w-sm mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Identify Any Plant</h2>
        <p className="text-gray-600">Take a photo or upload an image to identify plants instantly</p>
      </div>

      <Card 
        className={`border-2 border-dashed ${isDragging ? 'border-primary' : 'border-primary-light/50'} rounded-xl p-8 text-center bg-white`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center">
          <div className="text-5xl text-primary-light mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
              <line x1="9" y1="13" x2="15" y2="13"></line>
              <line x1="12" y1="10" x2="12" y2="16"></line>
            </svg>
          </div>
          <p className="mb-4">Drag and drop a photo or use the button below</p>
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={handleFileChange}
          />
          <Button 
            onClick={(e) => {
              console.log("Upload button clicked directly");
              triggerFileInput();
            }}
            className="bg-primary text-white px-6 py-3 rounded-full font-semibold shadow-md hover:bg-opacity-90 transition-all"
            type="button"
          >
            Upload Image
          </Button>
        </div>
      </Card>

      {/* Alternative direct file input for users having issues with the button */}
      <div className="mt-4 text-center">
        <label htmlFor="direct-file-input" className="text-sm text-gray-500">
          Having trouble with the camera? Try uploading a plant photo instead:
        </label>
        <input
          id="direct-file-input"
          type="file"
          accept="image/*"
          className="mt-2 w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-primary-dark"
          onChange={handleFileChange}
        />
      </div>
      
      {/* Camera troubleshooting tips */}
      <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <h3 className="font-semibold text-amber-800 mb-2">Camera Not Working Properly?</h3>
        <ul className="text-sm text-amber-700 list-disc pl-5 space-y-1">
          <li>Make sure you have good lighting</li>
          <li>Allow camera permissions in your browser</li>
          <li>Try uploading a photo if camera doesn't work</li>
          <li>Clear, in-focus photos work best</li>
          <li>Include the whole plant in the shot if possible</li>
          <li><strong>Mac users: You can now choose to use dark images when prompted</strong></li>
        </ul>
      </div>

      <div className="w-full max-w-sm mx-auto mt-4 space-y-3">
        <Button
          onClick={onCameraClick}
          variant="outline"
          className="w-full border border-primary text-primary px-6 py-3 rounded-full font-semibold shadow-sm hover:bg-primary hover:text-white transition-all flex items-center justify-center"
          type="button"
        >
          <span className="mr-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
              <circle cx="12" cy="13" r="3"></circle>
            </svg>
          </span>
          Take a Photo
        </Button>
        
        {onSampleClick && (
          <Button
            onClick={onSampleClick}
            variant="secondary"
            className="w-full border border-amber-500 text-amber-600 px-6 py-3 rounded-full font-semibold shadow-sm hover:bg-amber-500 hover:text-white transition-all flex items-center justify-center"
            type="button"
          >
            <span className="mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22c6.23-.05 7.87-5.57 7.5-10-.36-4.34-3.95-9.96-7.5-10-3.55.04-7.14 5.66-7.5 10-.37 4.43 1.27 9.95 7.5 10z"></path>
              </svg>
            </span>
            Try Sample Plant Image
          </Button>
        )}
      </div>
    </div>
  );
}
