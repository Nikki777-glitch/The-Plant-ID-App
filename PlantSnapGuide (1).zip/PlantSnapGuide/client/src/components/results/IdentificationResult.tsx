import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { CareInfoItem } from './CareInfoItem';
import { PlantIdentificationResult } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { savePlant } from '@/lib/plantApi';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface IdentificationResultProps {
  plant: PlantIdentificationResult;
  onNewScan: () => void;
}

export function IdentificationResult({ plant, onNewScan }: IdentificationResultProps) {
  const [activeTab, setActiveTab] = useState('care');
  const { toast } = useToast();
  
  // Sample learning resources for plants
  const learningResources = [
    {
      title: "Complete Care Guide",
      description: `Learn everything you need to know about caring for your ${plant.name}, from basic maintenance to advanced techniques.`,
      icon: "book",
      link: "#"
    },
    {
      title: "Video Tutorials",
      description: "Watch step-by-step video guides on proper planting, watering, and maintenance techniques.",
      icon: "video",
      link: "#"
    },
    {
      title: "Seasonal Care Tips",
      description: `Discover how to adjust your ${plant.name} care routine throughout the different seasons of the year.`,
      icon: "calendar",
      link: "#"
    },
    {
      title: "Common Problems & Solutions",
      description: "Identify and solve common issues like pests, diseases, and growth problems.",
      icon: "alert-circle",
      link: "#"
    }
  ];
  
  // Add debug logs to check plant data
  useEffect(() => {
    console.log("Plant data in IdentificationResult:", plant);
    console.log("Details available:", !!plant.details);
    console.log("Similar plants available:", !!plant.similarPlants);
    if (plant.details) console.log("Plant details:", plant.details);
    if (plant.similarPlants) console.log("Similar plants:", plant.similarPlants);
  }, [plant]);

  const saveMutation = useMutation({
    mutationFn: savePlant,
    onSuccess: () => {
      toast({
        title: "Plant saved!",
        description: `${plant.name} has been added to your collection.`,
        variant: "default",
      });
      // Invalidate recent plants query
      queryClient.invalidateQueries({ queryKey: ['/api/plants/recent'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save plant to collection. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSaveToCollection = () => {
    saveMutation.mutate(plant);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        {/* Plant Image */}
        <div className="h-56 bg-gray-200 relative">
          {plant.imageUrl ? (
            <img src={plant.imageUrl} alt={plant.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-200">
              <span className="text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22c6.23-.05 7.87-5.57 7.5-10-.36-4.34-3.95-9.96-7.5-10-3.55.04-7.14 5.66-7.5 10-.37 4.43 1.27 9.95 7.5 10z"></path>
                  <path d="M12 6c-1.2 1.82-2 3.66-2 5.5 0 2.32 1.03 4.17 2 5.5 1.2-1.82 2-3.66 2-5.5 0-2.32-1.03-4.17-2-5.5z"></path>
                </svg>
              </span>
            </div>
          )}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-white">
            <div className="flex items-center">
              <div className="flex-1">
                <h2 className="text-2xl font-bold">{plant.name}</h2>
                <p className="text-sm opacity-90">{plant.scientificName || 'Scientific name unavailable'}</p>
              </div>
              {plant.confidence !== undefined && (
                <div className="bg-primary-light rounded-full px-3 py-1 text-sm font-semibold">
                  <span>{plant.confidence}% Match</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Plant Info Tabs */}
        <div className="px-4 pt-4">
          <div className="flex border-b border-gray-200 overflow-x-auto hide-scrollbar">
            <button 
              type="button"
              className={`px-4 py-2 font-semibold whitespace-nowrap ${activeTab === 'care' ? 'border-b-2 border-primary text-primary' : 'text-gray-600'}`}
              onClick={(e) => {
                e.preventDefault();
                console.log("Care tab clicked");
                setActiveTab('care');
              }}
            >
              Care Guide
            </button>
            <button 
              type="button"
              className={`px-4 py-2 font-semibold whitespace-nowrap ${activeTab === 'details' ? 'border-b-2 border-primary text-primary' : 'text-gray-600'}`}
              onClick={(e) => {
                e.preventDefault();
                console.log("Details tab clicked");
                setActiveTab('details');
              }}
            >
              Details
            </button>
            <button 
              type="button"
              className={`px-4 py-2 font-semibold whitespace-nowrap ${activeTab === 'similar' ? 'border-b-2 border-primary text-primary' : 'text-gray-600'}`}
              onClick={(e) => {
                e.preventDefault();
                console.log("Similar Plants tab clicked");
                setActiveTab('similar');
              }}
            >
              Similar Plants
            </button>
            <button 
              type="button"
              className={`px-4 py-2 font-semibold whitespace-nowrap ${activeTab === 'learn' ? 'border-b-2 border-primary text-primary' : 'text-gray-600'}`}
              onClick={(e) => {
                e.preventDefault();
                console.log("Learn More tab clicked");
                setActiveTab('learn');
              }}
            >
              Learn More
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'care' && plant.careInfo && (
          <div className="p-4 space-y-4">
            <CareInfoItem 
              icon={plant.careInfo.water.icon}
              title={plant.careInfo.water.title}
              description={plant.careInfo.water.description}
            />
            <CareInfoItem 
              icon={plant.careInfo.light.icon}
              title={plant.careInfo.light.title}
              description={plant.careInfo.light.description}
            />
            <CareInfoItem 
              icon={plant.careInfo.temperature.icon}
              title={plant.careInfo.temperature.title}
              description={plant.careInfo.temperature.description}
            />
            <CareInfoItem 
              icon={plant.careInfo.humidity.icon}
              title={plant.careInfo.humidity.title}
              description={plant.careInfo.humidity.description}
            />

            <Button
              onClick={(e) => {
                e.preventDefault();
                console.log("Save to collection button clicked");
                handleSaveToCollection();
              }}
              disabled={saveMutation.isPending}
              className="w-full bg-primary text-white px-6 py-3 rounded-full font-semibold shadow-md hover:bg-opacity-90 transition-all mt-4"
              type="button"
            >
              {saveMutation.isPending ? 'Saving...' : 'Save to My Collection'}
            </Button>
          </div>
        )}
        
        {activeTab === 'details' && (
          <div className="p-4 space-y-4">
            {plant.details ? (
              <>
                <div className="mb-3">
                  <h3 className="font-semibold text-gray-700">Origin</h3>
                  <p className="text-gray-600">{plant.details.origin}</p>
                </div>
                <div className="mb-3">
                  <h3 className="font-semibold text-gray-700">Family</h3>
                  <p className="text-gray-600">{plant.details.family}</p>
                </div>
                <div className="mb-3">
                  <h3 className="font-semibold text-gray-700">Description</h3>
                  <p className="text-gray-600">{plant.details.description}</p>
                </div>
                <div className="mb-3">
                  <h3 className="font-semibold text-gray-700">Uses</h3>
                  <p className="text-gray-600">{plant.details.uses}</p>
                </div>
                <div className="mb-3">
                  <h3 className="font-semibold text-gray-700">Toxicity</h3>
                  <p className="text-gray-600">{plant.details.toxicity}</p>
                </div>
              </>
            ) : (
              <p className="text-gray-600">
                Additional details about this plant are loading...
              </p>
            )}
          </div>
        )}
        
        {activeTab === 'similar' && (
          <div className="p-4">
            {plant.similarPlants && plant.similarPlants.length > 0 ? (
              <div className="space-y-4">
                {plant.similarPlants.map((similarPlant, index) => (
                  <div key={index} className="bg-gray-50 p-3 rounded-lg shadow-sm">
                    <h3 className="font-semibold">{similarPlant.name}</h3>
                    {similarPlant.scientificName && (
                      <p className="text-sm italic text-gray-500">{similarPlant.scientificName}</p>
                    )}
                    <p className="text-sm text-gray-600 mt-1">{similarPlant.similarity}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600">
                Similar plants information is loading...
              </p>
            )}
          </div>
        )}

        {/* Learn More Tab */}
        {activeTab === 'learn' && (
          <div className="p-4">
            <div className="mb-4">
              <h3 className="font-semibold text-gray-700 mb-2">In-Depth Learning Resources</h3>
              <p className="text-gray-600 text-sm">
                Expand your knowledge about {plant.name} with these resources and articles.
              </p>
            </div>
            
            <div className="space-y-4">
              {learningResources.map((resource, index) => (
                <div key={index} className="bg-white border border-gray-100 rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start">
                    <div className="bg-indigo-50 rounded-full p-3 mr-4">
                      {resource.icon === "book" && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                      )}
                      {resource.icon === "video" && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      )}
                      {resource.icon === "calendar" && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      )}
                      {resource.icon === "alert-circle" && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      )}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800">{resource.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{resource.description}</p>
                      <a 
                        href={resource.link} 
                        className="inline-block mt-2 text-sm font-medium text-indigo-600 hover:text-indigo-800 flex items-center"
                      >
                        Learn more
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-indigo-50 rounded-lg border border-indigo-100">
              <h4 className="font-semibold text-indigo-800 mb-2 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Did you know?
              </h4>
              <p className="text-sm text-indigo-700">
                Plants like {plant.name} can significantly improve air quality by absorbing toxins and producing oxygen. They've been shown to reduce stress, boost creativity, and enhance overall well-being.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* New Scan Button */}
      <div className="w-full max-w-md mx-auto mt-6 mb-20">
        <Button
          onClick={(e) => {
            e.preventDefault();
            console.log("Scan Another Plant button clicked");
            onNewScan();
          }}
          variant="outline"
          className="w-full border border-primary text-primary px-6 py-3 rounded-full font-semibold shadow-sm hover:bg-primary hover:text-white transition-all flex items-center justify-center"
          type="button"
        >
          <span className="mr-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
              <line x1="9" y1="13" x2="15" y2="13"></line>
              <line x1="12" y1="10" x2="12" y2="16"></line>
            </svg>
          </span>
          Scan Another Plant
        </Button>
      </div>
    </div>
  );
}
