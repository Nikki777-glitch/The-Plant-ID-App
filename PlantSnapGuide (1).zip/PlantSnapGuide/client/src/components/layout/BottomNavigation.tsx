import React from 'react';
import { useLocation } from 'wouter';

interface BottomNavigationProps {
  onIdentifyClick: () => void;
}

export function BottomNavigation({ onIdentifyClick }: BottomNavigationProps) {
  const [location, setLocation] = useLocation();

  const navigateTo = (page: string) => {
    setLocation(`/${page === 'home' ? '' : page}`);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t border-gray-200 z-10">
      <div className="flex justify-around">
        <button 
          className={`flex flex-col items-center py-3 px-5 ${location === '/' ? 'text-primary' : 'text-gray-500'}`} 
          onClick={(e) => {
            e.preventDefault();
            console.log("Home button clicked");
            navigateTo('home');
          }}
          type="button"
        >
          <span className="h-6 w-6">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
              <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
          </span>
          <span className="text-xs mt-1">Home</span>
        </button>
        <button 
          className={`flex flex-col items-center py-3 px-5 ${location === '/search' ? 'text-primary' : 'text-gray-500'}`} 
          onClick={(e) => {
            e.preventDefault();
            console.log("Search button clicked");
            navigateTo('search');
          }}
          type="button"
        >
          <span className="h-6 w-6">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.3-4.3"></path>
            </svg>
          </span>
          <span className="text-xs mt-1">Search</span>
        </button>
        <button 
          className="flex flex-col items-center py-2 px-5"
          onClick={(e) => {
            e.preventDefault();
            console.log("Identify button clicked");
            onIdentifyClick();
          }}
          type="button"
        >
          <div className="bg-primary text-white rounded-full p-2 -mt-5 shadow-lg">
            <span className="h-6 w-6">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"></path>
                <circle cx="12" cy="13" r="3"></circle>
              </svg>
            </span>
          </div>
          <span className="text-xs mt-1">Identify</span>
        </button>
        <button 
          className={`flex flex-col items-center py-3 px-5 ${location === '/collection' ? 'text-primary' : 'text-gray-500'}`} 
          onClick={(e) => {
            e.preventDefault();
            console.log("Collection button clicked");
            navigateTo('collection');
          }}
          type="button"
        >
          <span className="h-6 w-6">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
              <line x1="7" y1="7" x2="7.01" y2="7"></line>
            </svg>
          </span>
          <span className="text-xs mt-1">Collection</span>
        </button>
        <button 
          className={`flex flex-col items-center py-3 px-5 ${location === '/profile' ? 'text-primary' : 'text-gray-500'}`} 
          onClick={(e) => {
            e.preventDefault();
            console.log("Profile button clicked");
            navigateTo('profile');
          }}
          type="button"
        >
          <span className="h-6 w-6">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </span>
          <span className="text-xs mt-1">Profile</span>
        </button>
      </div>
    </nav>
  );
}
