import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";
import { LogOut, User, CreditCard, Leaf, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";

export function UserMenu() {
  const { user, isLoading, logoutMutation } = useAuth();
  const [_, setLocation] = useLocation();
  
  // Show loader while checking auth status
  if (isLoading) {
    return (
      <Button variant="ghost" size="icon" disabled>
        <Loader2 className="h-5 w-5 animate-spin" />
      </Button>
    );
  }
  
  // Show login button if not authenticated
  if (!user) {
    return (
      <Button variant="default" onClick={() => setLocation("/auth")}>
        Sign in
      </Button>
    );
  }
  
  // Get initials for avatar
  const getInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };
  
  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Get subscription badge style and text
  const getSubscriptionBadge = () => {
    if (!user.subscriptionStatus) return null;
    
    switch (user.subscriptionStatus) {
      case "active":
        return <Badge variant="default" className="bg-green-600">Premium</Badge>;
      case "free_trial":
        return <Badge variant="default" className="bg-blue-600">Trial</Badge>;
      default:
        return <Badge variant="outline">Free</Badge>;
    }
  };
  
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative rounded-full h-8 w-8 p-0">
          <Avatar className="h-8 w-8 border border-green-200 dark:border-green-800">
            <AvatarFallback className="bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
              {getInitials(user.username)}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="flex flex-col">
          <div className="flex justify-between items-center">
            <span>{user.username}</span>
            {getSubscriptionBadge()}
          </div>
          <span className="font-normal text-xs text-gray-500 truncate">
            {user.email}
          </span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => setLocation("/account")}>
          <User className="mr-2 h-4 w-4" />
          <span>Account</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setLocation("/my-plants")}>
          <Leaf className="mr-2 h-4 w-4" />
          <span>My Plants</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setLocation("/subscription")}>
          <CreditCard className="mr-2 h-4 w-4" />
          <span>Subscription</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          {logoutMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              <span>Logging out...</span>
            </>
          ) : (
            <>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </>
          )}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}