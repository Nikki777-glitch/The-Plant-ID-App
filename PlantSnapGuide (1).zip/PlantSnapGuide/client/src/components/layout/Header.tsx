import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { UserMenu } from './UserMenu';

interface HeaderProps {
  onUserMenuClick?: () => void;
}

export function Header({ onUserMenuClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();
  
  // Helper to determine active link
  const isActive = (path: string) => location === path;
  
  return (
    <header className="bg-primary text-white shadow-md">
      {/* Main header bar */}
      <div className="container mx-auto p-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <span className="h-6 w-6 mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2c.2 0 .4.2.5.3l9 15c.1.2.1.4.1.5 0 .6-.4 1-1 1H3.6c-.2 0-.4 0-.5-.1a1 1 0 0 1-.4-.4 1 1 0 0 1 0-1l9-15A.7.7 0 0 1 12 2z"></path>
                  <path d="M12 6v10"></path>
                  <path d="M12 16v.5"></path>
                </svg>
              </span>
              <h1 className="text-xl font-bold">PlantID</h1>
            </div>
          </Link>
        </div>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/">
            <div className={`font-medium ${isActive('/') ? 'text-white' : 'text-primary-50 hover:text-white'} transition-colors cursor-pointer`}>
              Home
            </div>
          </Link>
          <Link href="/about">
            <div className={`font-medium ${isActive('/about') ? 'text-white' : 'text-primary-50 hover:text-white'} transition-colors cursor-pointer`}>
              About
            </div>
          </Link>
          <Link href="/contact">
            <div className={`font-medium ${isActive('/contact') ? 'text-white' : 'text-primary-50 hover:text-white'} transition-colors cursor-pointer`}>
              Contact
            </div>
          </Link>
          
          <UserMenu />
        </div>
        
        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center">
          <div className="mr-2">
            <UserMenu />
          </div>
          
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-white focus:outline-none"
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-6 w-6" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
              )}
            </svg>
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-primary-700 py-2">
          <nav className="container mx-auto px-4">
            <ul className="space-y-1">
              <li>
                <Link href="/">
                  <div className={`block py-2 px-3 rounded ${isActive('/') ? 'bg-primary-800 text-white' : 'text-primary-50 hover:bg-primary-800 hover:text-white'} cursor-pointer`}>
                    Home
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <div className={`block py-2 px-3 rounded ${isActive('/about') ? 'bg-primary-800 text-white' : 'text-primary-50 hover:bg-primary-800 hover:text-white'} cursor-pointer`}>
                    About
                  </div>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <div className={`block py-2 px-3 rounded ${isActive('/contact') ? 'bg-primary-800 text-white' : 'text-primary-50 hover:bg-primary-800 hover:text-white'} cursor-pointer`}>
                    Contact
                  </div>
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
}
