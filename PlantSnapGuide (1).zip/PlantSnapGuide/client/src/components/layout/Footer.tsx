import React from 'react';
import { Link } from 'wouter';

export function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-800 text-white p-6 mt-auto">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About Section */}
          <div>
            <h3 className="text-lg font-semibold mb-3">About PlantID</h3>
            <p className="text-gray-300 text-sm">
              PlantID is your AI-powered plant identification companion. 
              Simply take a photo of any plant and get instant identification 
              with detailed care instructions.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer">Home</div>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer">About</div>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <div className="text-gray-300 hover:text-white transition-colors cursor-pointer">Contact</div>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Contact Us</h3>
            <p className="text-gray-300 text-sm mb-2">
              Have questions or suggestions? We'd love to hear from you!
            </p>
            <p className="text-gray-300 text-sm">
              <a 
                href="mailto:funny.world3024@gmail.com" 
                className="hover:text-white transition-colors"
              >
                funny.world3024@gmail.com
              </a>
            </p>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
          <p>© {currentYear} PlantID. All rights reserved.</p>
          <p className="mt-1">
            Powered by AI technology to help you identify and care for your plants.
          </p>
        </div>
      </div>
    </footer>
  );
}