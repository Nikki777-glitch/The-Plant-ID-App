import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';

interface ErrorScreenProps {
  message?: string;
  onRetry: () => void;
}

export function ErrorScreen({ 
  message = "We couldn't identify this plant. Please try again with a clearer photo.", 
  onRetry 
}: ErrorScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full py-16">
      <div className="text-center max-w-sm mx-auto">
        <AlertCircle className="text-error h-16 w-16 mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Plant Not Recognized</h2>
        <p className="text-gray-600 mb-6">{message}</p>
        <Button 
          onClick={(e) => {
            e.preventDefault();
            console.log("Try Again button clicked");
            onRetry();
          }}
          className="bg-primary text-white px-6 py-3 rounded-full font-semibold shadow-md hover:bg-opacity-90 transition-all"
          type="button"
        >
          Try Again
        </Button>
      </div>
    </div>
  );
}
