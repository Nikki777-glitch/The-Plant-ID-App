import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

export async function takePictureWithCapacitor(): Promise<string> {
  try {
    // Check if we're running in a Capacitor environment
    const isCapacitor = typeof (window as any).Capacitor !== 'undefined';
    
    if (!isCapacitor) {
      throw new Error('Not running in Capacitor environment');
    }

    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Camera,
      promptLabelHeader: 'Take a Plant Photo',
      promptLabelPhoto: 'Choose from Gallery',
      promptLabelPicture: 'Take Picture'
    });

    return image.dataUrl || '';
  } catch (error) {
    console.error('Error taking picture with Capacitor:', error);
    throw error;
  }
}

export async function selectImageWithCapacitor(): Promise<string> {
  try {
    // Check if we're running in a Capacitor environment
    const isCapacitor = typeof (window as any).Capacitor !== 'undefined';
    
    if (!isCapacitor) {
      throw new Error('Not running in Capacitor environment');
    }

    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Photos,
      promptLabelHeader: 'Select a Plant Photo',
      promptLabelPhoto: 'Choose from Gallery',
    });

    return image.dataUrl || '';
  } catch (error) {
    console.error('Error selecting image with Capacitor:', error);
    throw error;
  }
}

export function isCapacitorEnvironment(): boolean {
  return typeof (window as any).Capacitor !== 'undefined';
}