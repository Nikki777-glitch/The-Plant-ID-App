import { apiRequest } from "./queryClient";
import { PlantIdentificationResult } from "@shared/schema";

// Function to identify a plant from an image
export async function identifyPlant(imageData: string): Promise<PlantIdentificationResult> {
  const res = await apiRequest('POST', '/api/identify', { imageData });
  return await res.json();
}

// Function to save an identified plant to the user's collection
export async function savePlant(plant: PlantIdentificationResult): Promise<PlantIdentificationResult> {
  const res = await apiRequest('POST', '/api/plants', plant);
  return await res.json();
}

// Function to get recent plant identifications
export async function getRecentPlants(limit = 5): Promise<PlantIdentificationResult[]> {
  const res = await fetch(`/api/plants/recent?limit=${limit}`, {
    credentials: 'include'
  });
  if (!res.ok) {
    throw new Error('Failed to fetch recent plants');
  }
  return await res.json();
}

// Function to convert File to base64
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
}
