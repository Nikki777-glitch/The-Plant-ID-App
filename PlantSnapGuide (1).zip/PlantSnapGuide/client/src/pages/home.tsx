import React, { useState, useEffect, useRef } from 'react';
import { Header } from '@/components/layout/Header';
import { BottomNavigation } from '@/components/layout/BottomNavigation';
import { Footer } from '@/components/layout/Footer';
import { UploadArea } from '@/components/upload/UploadArea';
import { LoadingScreen } from '@/components/loading/LoadingScreen';
import { ErrorScreen } from '@/components/error/ErrorScreen';
import { IdentificationResult } from '@/components/results/IdentificationResult';
import { PlantIdentificationResult } from '@shared/schema';
import { useQuery, useMutation } from '@tanstack/react-query';
import { identifyPlant, getRecentPlants } from '@/lib/plantApi';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { isCapacitorEnvironment, takePictureWithCapacitor, selectImageWithCapacitor } from '@/lib/capacitorCamera';

type ScreenState = 'upload' | 'loading' | 'results' | 'error';

export default function Home() {
  const [screenState, setScreenState] = useState<ScreenState>('upload');
  const [identifiedPlant, setIdentifiedPlant] = useState<PlantIdentificationResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const { toast } = useToast();
  const { user, isLoading: authLoading } = useAuth();
  const [_, setLocation] = useLocation();
  
  // Redirect to auth page if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Authentication Required",
        description: "You need to log in to use the plant identification feature.",
        variant: "destructive",
      });
      setLocation("/auth");
    }
  }, [user, authLoading, setLocation, toast]);
  
  // Show loading state while checking authentication
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-green-200 dark:from-green-950 dark:to-green-900">
        <div className="text-center">
          <div className="animate-spin h-12 w-12 mx-auto mb-4 border-4 border-green-600 border-t-transparent rounded-full"></div>
          <p className="text-lg text-green-800 dark:text-green-200">Loading PlantID...</p>
        </div>
      </div>
    );
  }
  
  // Redirect if not authenticated
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-green-200 dark:from-green-950 dark:to-green-900 p-6">
        <div className="text-center max-w-md bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg">
          <div className="text-green-600 dark:text-green-400 text-5xl mb-4">🔒</div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Authentication Required</h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            You need to log in or create an account to use the plant identification feature.
          </p>
          <button 
            onClick={() => setLocation("/auth")}
            className="w-full py-2 px-4 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 transition-all"
          >
            Log In or Register
          </button>
        </div>
      </div>
    );
  }

  // Query for recent plant identifications
  const { data: recentPlants, error: recentPlantsError, isLoading: recentPlantsLoading } = useQuery({
    queryKey: ['/api/plants/recent'],
    queryFn: () => getRecentPlants(5)
  });
  
  // Query for subscription data
  const { data: subscription } = useQuery({
    queryKey: ['/api/subscription'],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/subscription");
        if (!res.ok) {
          return { status: "inactive" };
        }
        return await res.json();
      } catch (error) {
        return { status: "inactive" };
      }
    },
    enabled: !!user // Only run this query if user is authenticated
  });

  // Mutation for plant identification
  const identifyMutation = useMutation({
    mutationFn: identifyPlant,
    onMutate: () => {
      setScreenState('loading');
    },
    onSuccess: (data) => {
      console.log("Plant identification data:", data);
      setIdentifiedPlant(data);
      setScreenState('results');
    },
    onError: (error: Error) => {
      setErrorMessage(error.message || "We couldn't identify this plant. Please try again with a clearer photo.");
      setScreenState('error');
    }
  });

  const handleImageUpload = (imageData: string) => {
    // Verify that we have valid image data
    if (!imageData || !imageData.includes('base64,')) {
      console.error("Invalid image data format");
      toast({
        title: "Invalid Image",
        description: "The image format is not supported. Please try a different image.",
        variant: "destructive",
      });
      return;
    }
    
    // Ensure the image contains actual data
    const base64Part = imageData.split('base64,')[1];
    if (!base64Part || base64Part.trim() === "") {
      console.error("Empty image data");
      toast({
        title: "Invalid Image",
        description: "The image appears to be empty. Please try a different image.",
        variant: "destructive",
      });
      return;
    }
    
    identifyMutation.mutate(imageData);
  };

  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Function to use a test image if camera isn't working
  const useTestImage = () => {
    toast({
      title: "Using Sample Plant Image",
      description: "Providing a sample plant image for testing...",
      variant: "default",
    });
    
    // Create a canvas with a simple plant image
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      // Create a gradient background
      const gradient = ctx.createLinearGradient(0, 0, 640, 480);
      gradient.addColorStop(0, '#f0f8ff'); // Light blue sky background
      gradient.addColorStop(1, '#e6ffe6'); // Light green ground
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 640, 480);
      
      // Draw a plant pot
      ctx.fillStyle = '#CD7F32'; // Brown
      ctx.beginPath();
      ctx.moveTo(280, 400);
      ctx.lineTo(360, 400);
      ctx.lineTo(340, 300);
      ctx.lineTo(300, 300);
      ctx.closePath();
      ctx.fill();
      
      // Draw plant stem
      ctx.strokeStyle = '#006400'; // Dark green
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(320, 300);
      ctx.lineTo(320, 200);
      ctx.stroke();
      
      // Draw some leaves
      ctx.fillStyle = '#228B22'; // Forest green
      // Left leaf
      ctx.beginPath();
      ctx.ellipse(280, 220, 40, 20, Math.PI / 3, 0, 2 * Math.PI);
      ctx.fill();
      // Right leaf
      ctx.beginPath();
      ctx.ellipse(350, 250, 40, 20, -Math.PI / 3, 0, 2 * Math.PI);
      ctx.fill();
      // Top leaf
      ctx.beginPath();
      ctx.ellipse(320, 160, 30, 50, 0, 0, 2 * Math.PI);
      ctx.fill();
      
      // Generate the image data
      const imageData = canvas.toDataURL('image/jpeg', 0.9);
      console.log("Test image created");
      
      // Build a fake plant identification response for testing that matches our schema
      const mockPlantData = {
        id: 1001, // Fake ID for the plant
        name: "Snake Plant (Sansevieria)",
        scientificName: "Dracaena trifasciata",
        confidence: 95,
        imageUrl: imageData,
        details: {
          origin: "Native to West Africa from Nigeria to Congo",
          family: "Asparagaceae",
          description: "An evergreen perennial plant with stiff, upright leaves that range from 1-8 feet tall. The leaves are dark green with light gray-green horizontal stripes.",
          uses: "Popular as an ornamental houseplant known for its air purifying abilities and low maintenance requirements.",
          toxicity: "Mildly toxic to pets if ingested, causing nausea and vomiting."
        },
        careInfo: {
          water: {
            icon: "water_drop",
            title: "Water",
            description: "Allow soil to dry completely between waterings. Water sparingly, especially in winter."
          },
          light: {
            icon: "wb_sunny",
            title: "Light",
            description: "Thrives in indirect light but tolerates low light and direct sun."
          },
          temperature: {
            icon: "thermostat",
            title: "Temperature",
            description: "Prefers warm temperatures between 70-90°F (21-32°C)."
          },
          humidity: {
            icon: "humidity_high",
            title: "Humidity",
            description: "Adapts to all humidity levels but prefers dry conditions."
          }
        },
        // Fix the similar plants structure to match our schema
        similarPlants: [
          {
            name: "Agave",
            similarity: "80%",
            scientificName: "Agave americana"
          },
          {
            name: "Aloe Vera",
            similarity: "75%",
            scientificName: "Aloe barbadensis miller"
          },
          {
            name: "ZZ Plant",
            similarity: "70%",
            scientificName: "Zamioculcas zamiifolia"
          }
        ],
        createdAt: new Date().toISOString()
      };
      
      // Instead of calling the API, just return our mock data
      setScreenState('results');
      setIdentifiedPlant(mockPlantData);
    }
  };

  // Handle camera functionality
  const handleCameraClick = async () => {
    // First, check if we're in a Capacitor (mobile app) environment
    if (isCapacitorEnvironment()) {
      try {
        console.log("Using Capacitor camera");
        setScreenState('loading');
        const imageData = await takePictureWithCapacitor();
        
        if (imageData) {
          // Process the image directly
          handleImageUpload(imageData);
        } else {
          toast({
            title: "Camera Error",
            description: "Failed to capture image. Please try again.",
            variant: "destructive",
          });
          setScreenState('upload');
        }
      } catch (error) {
        console.error("Error using Capacitor camera:", error);
        toast({
          title: "Camera Error",
          description: "Could not access your camera. Using sample plant image instead.",
          variant: "destructive",
        });
        
        // Use sample image as fallback
        useTestImage();
      }
      return;
    }
    
    // Web browser camera implementation for non-mobile environments
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // If camera is already open, close it
        if (showCamera) {
          stopCamera();
          return;
        }

        // Show camera interface immediately to improve perceived performance
        setShowCamera(true);
        
        // First try with ideal settings for most devices
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
              facingMode: 'environment', // Use back camera if available
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }, 
            audio: false 
          });
          
          setCameraStream(stream);
          
          // Set video stream and add event handlers
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            
            // Wait a small amount of time then try to play the video
            setTimeout(() => {
              if (videoRef.current) {
                videoRef.current.play().catch(e => {
                  console.log('Auto-play failed, but this is expected on some browsers:', e);
                });
              }
            }, 300);
          }
        } catch (err) {
          console.warn("First camera attempt failed, trying backup method:", err);
          
          // Fallback to basic camera settings
          const backupStream = await navigator.mediaDevices.getUserMedia({ 
            video: true, 
            audio: false 
          });
          
          setCameraStream(backupStream);
          
          if (videoRef.current) {
            videoRef.current.srcObject = backupStream;
            videoRef.current.play().catch(e => {
              console.log('Backup play method failed:', e);
            });
          }
        }
      } else {
        toast({
          title: "Camera Not Available",
          description: "Your device does not support camera access. Using sample plant image instead.",
          variant: "destructive",
        });
        
        // Automatically use test image
        useTestImage();
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Camera Error",
        description: "Could not access your camera. Using sample plant image instead.",
        variant: "destructive",
      });
      
      // Automatically use test image
      useTestImage();
    }
  };
  
  // Stop camera stream
  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setShowCamera(false);
  };
  
  // Take photo from camera
  const handleCapturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Use fixed dimensions for the canvas instead of relying on video dimensions
      // Many mobile browsers have issues with videoWidth/videoHeight 
      canvas.width = 640;
      canvas.height = 480;
      
      // Draw video frame to canvas
      const ctx = canvas.getContext('2d');
      if (ctx) {
        try {
          // Immediately continue without waiting for video ready state
          console.log("Taking photo...");
          setScreenState('loading'); // Show loading screen immediately
          
          // Temporary fix for Mac camera issues - try to brighten the image
          // First, fill the canvas with a light background to help with dark images
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Now draw the video frame on top with slightly increased brightness
          ctx.globalAlpha = 0.9; // Slightly transparent to mix with white background
          
          // Draw the video frame to the canvas with fixed dimensions
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          
          // Convert canvas to base64 image
          const imageData = canvas.toDataURL('image/jpeg', 0.9);
          
          // Validate the data URL format
          if (!imageData || imageData === 'data:,' || !imageData.includes('base64')) {
            throw new Error("Invalid image data captured");
          }
          
          console.log("Image captured from camera", imageData.substring(0, 50) + "...");
          
          // Stop the camera stream
          stopCamera();
          
          // Mac camera fix - check if the image contains dark pixels (possible black image)
          const img = new Image();
          img.onload = () => {
            try {
              // Draw the image on a new canvas for pixel analysis
              const testCanvas = document.createElement('canvas');
              testCanvas.width = img.width;
              testCanvas.height = img.height;
              const testCtx = testCanvas.getContext('2d');
              
              if (testCtx) {
                testCtx.drawImage(img, 0, 0);
                
                // Get image data to analyze pixels
                const imgData = testCtx.getImageData(0, 0, testCanvas.width, testCanvas.height);
                const pixels = imgData.data;
                
                // Check if image is primarily black or very dark
                let darkPixelCount = 0;
                let totalPixels = pixels.length / 4; // RGBA values
                
                for (let i = 0; i < pixels.length; i += 4) {
                  const r = pixels[i];
                  const g = pixels[i + 1];
                  const b = pixels[i + 2];
                  
                  // If pixel is very dark
                  if (r < 30 && g < 30 && b < 30) {
                    darkPixelCount++;
                  }
                }
                
                // If more than 90% of pixels are dark, likely a black image from Mac camera
                const darkPercentage = darkPixelCount / totalPixels;
                console.log(`Dark pixel percentage: ${darkPercentage * 100}%`);
                
                if (darkPercentage > 0.9) {
                  console.log("Dark image detected - automatically enhancing it");
                  
                  // Try to enhance the image first by increasing brightness
                  const enhancementCanvas = document.createElement('canvas');
                  enhancementCanvas.width = testCanvas.width;
                  enhancementCanvas.height = testCanvas.height;
                  const enhancementCtx = enhancementCanvas.getContext('2d');
                  
                  if (enhancementCtx) {
                    // Draw a white background first
                    enhancementCtx.fillStyle = '#ffffff';
                    enhancementCtx.fillRect(0, 0, enhancementCanvas.width, enhancementCanvas.height);
                    
                    // Then draw the original image with increased brightness
                    enhancementCtx.globalAlpha = 0.7; // Mix with white background
                    enhancementCtx.drawImage(img, 0, 0);
                    
                    // Apply a brightness filter
                    enhancementCtx.globalCompositeOperation = 'lighter';
                    enhancementCtx.fillStyle = 'rgba(255, 255, 255, 0.5)';
                    enhancementCtx.fillRect(0, 0, enhancementCanvas.width, enhancementCanvas.height);
                    
                    // Get the enhanced image data
                    const enhancedImageData = enhancementCanvas.toDataURL('image/jpeg', 0.9);
                    
                    // Automatically use the enhanced image without asking
                    console.log("Automatically using enhanced image");
                    identifyMutation.mutate(enhancedImageData);
                  } else {
                    // If enhancement fails, use original image anyway
                    console.log("Enhancement failed, using original image");
                    identifyMutation.mutate(imageData);
                  }
                } else {
                  // Image seems ok, process it
                  identifyMutation.mutate(imageData);
                }
              } else {
                // Fallback if context couldn't be created
                identifyMutation.mutate(imageData);
              }
            } catch (error) {
              console.error("Error analyzing image:", error);
              identifyMutation.mutate(imageData); // Process anyway as fallback
            }
          };
          
          // Handle image load error
          img.onerror = () => {
            console.error("Error loading image for analysis");
            identifyMutation.mutate(imageData); // Process anyway as fallback
          };
          
          // Set the source to trigger loading
          img.src = imageData;
        } catch (error) {
          console.error("Error capturing image:", error);
          toast({
            title: "Error",
            description: "Failed to capture image. Using sample plant image instead.",
            variant: "destructive",
          });
          stopCamera();
          
          // Automatically use test image on error without asking
          useTestImage();
        }
      }
    } else {
      toast({
        title: "Camera Error",
        description: "Camera not initialized properly. Using sample plant image instead.",
        variant: "destructive",
      });
      
      // Automatically use test image on error without asking
      useTestImage();
    }
  };

  const resetToUpload = () => {
    setScreenState('upload');
    setIdentifiedPlant(null);
    setErrorMessage('');
  };

  return (
    <div className="flex flex-col min-h-screen relative animated-gradient-bg">
      <Header />
      
      <main className="flex-1 p-4 pb-20">
        {/* Free Trial Banner */}
        {subscription && !subscription.isPremium && (
          <div className="mb-6 p-4 rounded-lg border border-green-200 bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900 dark:to-green-800 shadow-sm">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex-1">
                <h3 className="text-lg font-medium text-green-800 dark:text-green-200">
                  {subscription.trialEnd ? (
                    <>Free Trial - {subscription.daysLeft || 0} days left</>
                  ) : (
                    <>Upgrade to Premium</>
                  )}
                </h3>
                <p className="text-sm text-green-700 dark:text-green-300">
                  {subscription.trialEnd 
                    ? "After your trial ends, continue with unlimited plant identifications for just $0.99/month." 
                    : "Unlock unlimited plant identifications for just $0.99/month."}
                </p>
              </div>
              <button 
                onClick={() => setLocation("/subscription")}
                className="px-4 py-2 text-sm font-medium rounded-md text-white bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 shadow-sm transition-all"
              >
                Get Premium Plan
              </button>
            </div>
          </div>
        )}
        
        {/* Camera View Overlay */}
        {showCamera && (
          <div className="fixed inset-0 bg-black z-50 flex flex-col">
            <div className="flex justify-between items-center p-4 bg-black text-white">
              <h2 className="text-lg font-semibold">Take a Photo</h2>
              <button
                type="button"
                className="rounded-full bg-gray-800 p-2"
                onClick={stopCamera}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>
            </div>
            <div className="flex-1 relative bg-black">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline
                muted
                className="absolute inset-0 w-full h-full object-cover"
              />
              <canvas ref={canvasRef} className="hidden" />
              
              {/* Mac-friendly overlay instructions */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="bg-black bg-opacity-50 p-4 rounded-lg text-white text-center">
                  <p className="mb-2 font-bold">Make sure you have VERY bright lighting</p>
                  <p className="mb-2">Point the camera at a well-lit plant</p>
                  <p>Simply tap the button to capture</p>
                </div>
              </div>
            </div>
            <div className="p-4 bg-black flex justify-center items-center">
              <button
                type="button"
                className="rounded-full bg-white w-16 h-16 flex items-center justify-center"
                onClick={handleCapturePhoto}
              >
                <div className="rounded-full bg-white w-14 h-14 border-2 border-gray-300" />
              </button>
              
              {/* Help text */}
              <div className="text-white text-sm ml-4">
                Tap the button to take a photo
              </div>
            </div>
          </div>
        )}
        
        {screenState === 'upload' && (
          <>
            <UploadArea 
              onImageUpload={handleImageUpload} 
              onCameraClick={handleCameraClick}
              onSampleClick={useTestImage}
            />
            
            {/* How To Use Section */}
            <div className="w-full max-w-3xl mx-auto mt-12 mb-8 px-4">
              <h3 className="text-2xl font-bold text-center mb-6">How To Use PlantID</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Card 1 */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Take a Photo</h4>
                  <p className="text-gray-600 text-sm">Snap a clear photo of any plant you want to identify using your device's camera.</p>
                </div>
                
                {/* Card 2 */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Upload Image</h4>
                  <p className="text-gray-600 text-sm">Already have a plant photo? Simply upload it from your device's gallery.</p>
                </div>
                
                {/* Card 3 */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Instant Analysis</h4>
                  <p className="text-gray-600 text-sm">Our AI instantly processes your image and identifies your plant with high accuracy.</p>
                </div>
                
                {/* Card 4 */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Detailed Info</h4>
                  <p className="text-gray-600 text-sm">Get comprehensive information about the plant's needs, characteristics, and origin.</p>
                </div>
                
                {/* Card 5 */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Care Tips</h4>
                  <p className="text-gray-600 text-sm">Learn how to properly care for your plant with customized watering, light, and temperature guidance.</p>
                </div>
                
                {/* Card 6 */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Save to Collection</h4>
                  <p className="text-gray-600 text-sm">Build your personal plant collection for quick reference and care reminders.</p>
                </div>
                
                {/* Card 7 - Learning Resources */}
                <div className="bg-white rounded-lg shadow-md p-5 flex flex-col items-center text-center transition-transform hover:scale-105">
                  <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Learn More</h4>
                  <p className="text-gray-600 text-sm">Access in-depth articles and educational resources related to your identified plant for continued learning.</p>
                </div>
              </div>
            </div>
            
            {/* Recent Identifications */}
            <div className="w-full max-w-sm mx-auto mt-8">
              <h3 className="text-lg font-semibold mb-3">Recent Identifications</h3>
              
              {recentPlantsLoading && (
                <div className="text-center p-4">
                  <div className="animate-pulse h-4 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
                  <div className="animate-pulse h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
                </div>
              )}
              
              {recentPlantsError && (
                <div className="bg-white rounded-lg shadow-md p-4 text-center text-gray-500">
                  Failed to load recent identifications
                </div>
              )}
              
              {recentPlants && recentPlants.length === 0 && (
                <div className="bg-white rounded-lg shadow-md p-4 text-center text-gray-500">
                  No recent plant identifications
                </div>
              )}
              
              {recentPlants && recentPlants.length > 0 && (
                <>
                  {recentPlants.map((plant) => (
                    <div key={plant.id} className="bg-white rounded-lg shadow-md p-4 mb-3 flex items-center">
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-200 mr-4 flex-shrink-0">
                        {plant.imageUrl ? (
                          <img src={plant.imageUrl} alt={plant.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-gray-200">
                            <span className="text-gray-400">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M12 22c6.23-.05 7.87-5.57 7.5-10-.36-4.34-3.95-9.96-7.5-10-3.55.04-7.14 5.66-7.5 10-.37 4.43 1.27 9.95 7.5 10z"></path>
                              </svg>
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold">{plant.name}</h4>
                        <p className="text-sm text-gray-600">
                          Identified on {plant.createdAt ? format(new Date(plant.createdAt), 'MMM d, yyyy') : 'Unknown date'}
                        </p>
                      </div>
                      <span className="text-primary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                      </span>
                    </div>
                  ))}
                </>
              )}
            </div>
          </>
        )}

        {screenState === 'loading' && (
          <LoadingScreen />
        )}

        {screenState === 'results' && identifiedPlant && (
          <IdentificationResult 
            plant={identifiedPlant} 
            onNewScan={resetToUpload} 
          />
        )}

        {screenState === 'error' && (
          <ErrorScreen 
            message={errorMessage} 
            onRetry={resetToUpload} 
          />
        )}
      </main>

      <BottomNavigation onIdentifyClick={resetToUpload} />
      <Footer />
    </div>
  );
}
