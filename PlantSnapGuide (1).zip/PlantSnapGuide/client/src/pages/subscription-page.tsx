import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Check, X, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { useLocation } from "wouter";

type SubscriptionData = {
  status: string;
  currentPeriodEnd?: string;
  cancelAtPeriodEnd?: boolean;
  isPremium?: boolean;
  trialEnd?: string;
  daysLeft?: number;
};

export default function SubscriptionPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const [isCheckoutLoading, setIsCheckoutLoading] = useState(false);
  
  // Redirect if not logged in
  if (!user) {
    setLocation("/auth");
    return null;
  }
  
  // Fetch subscription data
  const { data: subscription, isLoading, error } = useQuery<SubscriptionData>({
    queryKey: ["/api/subscription"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/subscription");
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Error fetching subscription");
      }
      return await res.json();
    },
  });
  
  // Handle subscription cancellation
  const cancelMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/cancel-subscription");
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Error canceling subscription");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Subscription canceled",
        description: "Your subscription will remain active until the end of the current billing period.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error canceling subscription",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle subscription reactivation
  const reactivateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/reactivate-subscription");
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Error reactivating subscription");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Subscription reactivated",
        description: "Your subscription has been reactivated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error reactivating subscription",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle checkout redirect
  const handleCheckout = async () => {
    try {
      setIsCheckoutLoading(true);
      const res = await apiRequest("POST", "/api/create-checkout-session");
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Error creating checkout session");
      }
      
      const { url } = await res.json();
      
      // Redirect to Stripe Checkout
      window.location.href = url;
    } catch (error: any) {
      toast({
        title: "Checkout error",
        description: error.message || "Error starting checkout process",
        variant: "destructive",
      });
    } finally {
      setIsCheckoutLoading(false);
    }
  };
  
  // Helper to format date
  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A";
    try {
      return format(new Date(dateString), "MMMM d, yyyy");
    } catch (e) {
      return "Invalid date";
    }
  };
  
  // Render loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-green-200 dark:from-green-950 dark:to-green-900">
        <Loader2 className="h-8 w-8 animate-spin text-green-600" />
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-green-200 dark:from-green-950 dark:to-green-900 p-4">
        <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
        <h1 className="text-xl font-semibold text-red-600 mb-2">Error Loading Subscription</h1>
        <p className="text-gray-700 dark:text-gray-300 mb-4">{error.message}</p>
        <Button onClick={() => setLocation("/")}>Return Home</Button>
      </div>
    );
  }
  
  // Determine subscription status display
  const getStatusDisplay = () => {
    if (!subscription) return { text: "Inactive", color: "bg-gray-200 text-gray-800" };
    
    switch(subscription.status) {
      case "active":
        return { text: "Active", color: "bg-green-200 text-green-800" };
      case "free_trial":
        return { text: "Free Trial", color: "bg-blue-200 text-blue-800" };
      case "canceled":
        return { text: "Canceled", color: "bg-amber-200 text-amber-800" };
      case "past_due":
        return { text: "Past Due", color: "bg-red-200 text-red-800" };
      default:
        return { text: "Inactive", color: "bg-gray-200 text-gray-800" };
    }
  };
  
  const statusDisplay = getStatusDisplay();
  
  // Format the features list
  const features = [
    {
      name: "Unlimited plant identifications",
      included: subscription?.isPremium || subscription?.status === "free_trial",
    },
    {
      name: "Detailed care instructions",
      included: true, // Available to all
    },
    {
      name: "Plant collection & history",
      included: true, // Available to all
    },
    {
      name: "Similar plant suggestions",
      included: subscription?.isPremium || subscription?.status === "free_trial",
    },
  ];
  
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-green-200 dark:from-green-950 dark:to-green-900 p-4">
      <div className="w-full max-w-3xl">
        <h1 className="text-3xl font-bold text-center text-green-800 dark:text-green-100 mb-8">
          Subscription Management
        </h1>
        
        <div className="grid gap-8">
          {/* Current Subscription Card */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Your Subscription</CardTitle>
                <Badge className={statusDisplay.color}>{statusDisplay.text}</Badge>
              </div>
              <CardDescription>
                {subscription?.status === "free_trial" ? 
                  `Your free trial ends on ${formatDate(subscription.trialEnd)}` : 
                  "Manage your PlantID Premium subscription"}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Trial Information */}
              {subscription?.status === "free_trial" && (
                <div className="bg-blue-50 dark:bg-blue-900 p-4 rounded-md">
                  <h3 className="font-medium text-blue-700 dark:text-blue-300 mb-2">
                    Trial Period
                  </h3>
                  <p className="text-sm text-blue-600 dark:text-blue-200">
                    You have {subscription.daysLeft} days left in your free trial.
                  </p>
                </div>
              )}
              
              {/* Subscription Details */}
              {subscription?.status === "active" && (
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Plan:</span>
                    <span className="font-medium">PlantID Premium Monthly</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Price:</span>
                    <span className="font-medium">$0.99/month</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Next billing date:</span>
                    <span className="font-medium">{formatDate(subscription.currentPeriodEnd)}</span>
                  </div>
                  
                  {subscription.cancelAtPeriodEnd && (
                    <div className="bg-amber-50 dark:bg-amber-900 p-4 rounded-md mt-4">
                      <h3 className="font-medium text-amber-700 dark:text-amber-300 mb-2">
                        Subscription Ending
                      </h3>
                      <p className="text-sm text-amber-600 dark:text-amber-200">
                        Your subscription is scheduled to end on {formatDate(subscription.currentPeriodEnd)}.
                      </p>
                    </div>
                  )}
                </div>
              )}
              
              {/* Feature List */}
              <div className="mt-6">
                <h3 className="font-medium mb-4">Included Features:</h3>
                <ul className="space-y-2">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      {feature.included ? (
                        <Check className="h-5 w-5 text-green-500 mr-2" />
                      ) : (
                        <X className="h-5 w-5 text-gray-400 mr-2" />
                      )}
                      <span className={feature.included ? "text-gray-900 dark:text-gray-100" : "text-gray-500"}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
            
            <CardFooter className="flex flex-col sm:flex-row gap-3 pt-2">
              {/* Show different buttons based on subscription status */}
              {subscription?.status === "inactive" && (
                <Button 
                  className="w-full bg-gradient-to-r from-green-600 to-green-500" 
                  onClick={handleCheckout}
                  disabled={isCheckoutLoading}
                >
                  {isCheckoutLoading ? "Processing..." : "Subscribe Now - $0.99/month"}
                </Button>
              )}
              
              {subscription?.status === "free_trial" && (
                <Button 
                  className="w-full bg-gradient-to-r from-green-600 to-green-500" 
                  onClick={handleCheckout}
                  disabled={isCheckoutLoading}
                >
                  {isCheckoutLoading ? "Processing..." : "Upgrade to Premium - $0.99/month"}
                </Button>
              )}
              
              {subscription?.status === "active" && !subscription.cancelAtPeriodEnd && (
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => cancelMutation.mutate()}
                  disabled={cancelMutation.isPending}
                >
                  {cancelMutation.isPending ? "Processing..." : "Cancel Subscription"}
                </Button>
              )}
              
              {subscription?.status === "active" && subscription.cancelAtPeriodEnd && (
                <Button 
                  className="w-full bg-gradient-to-r from-green-600 to-green-500" 
                  onClick={() => reactivateMutation.mutate()}
                  disabled={reactivateMutation.isPending}
                >
                  {reactivateMutation.isPending ? "Processing..." : "Reactivate Subscription"}
                </Button>
              )}
              
              <Button variant="outline" onClick={() => setLocation("/")}>
                Return Home
              </Button>
            </CardFooter>
          </Card>
          
          {/* Subscription Info Card */}
          <Card>
            <CardHeader>
              <CardTitle>About PlantID Premium</CardTitle>
              <CardDescription>
                Get unlimited plant identifications with our premium subscription
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <p className="text-gray-700 dark:text-gray-300 mb-4">
                With PlantID Premium, you can identify unlimited plants and get detailed care instructions.
                Our premium subscription is only $0.99/month and you can cancel at any time.
              </p>
              
              <div className="bg-green-50 dark:bg-green-900 p-4 rounded-md">
                <h3 className="font-medium text-green-700 dark:text-green-300 mb-2">
                  Need Help?
                </h3>
                <p className="text-sm text-green-600 dark:text-green-200">
                  If you have any questions about your subscription or need assistance,
                  please contact our support team at support@plantid.com
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}