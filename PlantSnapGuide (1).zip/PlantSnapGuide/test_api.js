// Test script for the plant identification API
import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import { fileURLToPath } from 'url';

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Function to convert file to base64
function fileToBase64(filePath) {
  const fileData = fs.readFileSync(filePath);
  return `data:image/jpeg;base64,${fileData.toString('base64')}`;
}

// Create a test image - a simple green circle to represent a plant
function createTestImage() {
  const testImagePath = path.join(__dirname, 'test_plant.jpg');
  
  console.log('Using a sample plant image for testing.');
  return testImagePath;
}

// Main function to test the API
async function testPlantIdentification() {
  try {
    // Create or use a test image
    let imagePath = createTestImage();
    
    // Check if the image exists
    if (!fs.existsSync(imagePath)) {
      console.error('Test image does not exist. Please provide a valid image path.');
      console.log('Looking for an existing image in the current directory...');
      
      // Look for an image in the current directory
      const files = fs.readdirSync(__dirname);
      const imageFile = files.find(file => 
        file.endsWith('.jpg') || file.endsWith('.jpeg') || 
        file.endsWith('.png') || file.endsWith('.gif')
      );
      
      if (imageFile) {
        console.log(`Found image: ${imageFile}`);
        imagePath = path.join(__dirname, imageFile);
      } else {
        console.error('No image files found in the current directory.');
        process.exit(1);
      }
    }
    
    // Convert image to base64
    console.log(`Converting image to base64: ${imagePath}`);
    const imageData = fileToBase64(imagePath);
    console.log('Image converted to base64.');
    
    // Send the request to the API
    console.log('Sending request to plant identification API...');
    const response = await fetch('http://localhost:5000/api/identify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ imageData }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`API error: ${response.status} ${errorText}`);
      return;
    }
    
    // Parse the response
    const result = await response.json();
    console.log('\n===== Plant Identification Result =====');
    console.log(`Plant Name: ${result.name}`);
    console.log(`Scientific Name: ${result.scientificName || 'N/A'}`);
    console.log(`Confidence: ${result.confidence}%`);
    
    console.log('\n===== Care Information =====');
    console.log(`Water: ${result.careInfo.water.description}`);
    console.log(`Light: ${result.careInfo.light.description}`);
    console.log(`Temperature: ${result.careInfo.temperature.description}`);
    console.log(`Humidity: ${result.careInfo.humidity.description}`);
    
    console.log('\n✅ API test successful!');
  } catch (error) {
    console.error('Error testing plant identification API:', error);
  }
}

// Run the test
console.log('Starting plant identification API test...');
testPlantIdentification();